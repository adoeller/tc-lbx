# LBXViewerWLX v3.4.54 — Windows-Binärversion 1.0.0 und englische Benutzeranleitung

Alle vom Projekt erzeugten `.dll`-/`.wlx`-/`.wlx64`- und `.exe`-Dateien
besitzen jetzt eine native Windows-Versionsressource: **Dateiversion 1.0.0**
(numerisch `1.0.0.0`) und **Produktversion 1.0.0**. Dies gilt auch für die
separaten b-PAC-Hosts, Test-EXEs und den mitgelieferten 32-Bit-BEC-Helfer.
Die Ressourcendateien liegen unter `resources/` und werden beim FPC-Build
direkt eingebettet. Der Build prüft die Ergebnisse mittels
`tools/verify-file-versions.ps1`. Das Programm-Release **v3.4.54** bleibt
unabhängig von der Windows-Binärversion.

Eine kurze **englische Anwenderdokumentation** steht in [`readme_user.md`](readme_user.md):
Beschreibung, Funktionen, Optionen und Bedienung.

**Tests:** 274 Python-Tests bestanden. Ob der Windows-FPC-Build die Ressourcen
korrekt einbindet, muss unter Windows mit `build.bat` und der neuen
Versionsprüfung bestätigt werden.

[Änderungen](CHANGELOG-v3.4.54.md) · [Testbericht](TESTREPORT-v3.4.54.md)

---

## Neu v3.4.53 – LTE-Mitteltext und Schriftgewicht

Bei `examples/Label Kabel LTE.lbx` reserviert der native Renderer den freien Mittelbereich zwischen zwei vor dem Text liegenden `Mobil-funk`-Textobjekten. Der 214-pt-CENTER-Text wird im verbleibenden Bereich von 49,6 bis 175,6 pt gezeichnet, statt die seitlichen Beschriftungen zu überlappen. Das gilt nur bei nachweislich symmetrischem Leerzeichenpolster und **beiden** überlagernden, gleich hohen Textfeldern; alle anderen Textobjekte behalten ihre Originalrechtecke.

Unsichtbare Leerzeichenläufe (`weight=700`) werden beim Zeichnen ohne Änderung der Quelldaten passend zu sichtbaren, normalgewichtigen Glyphen (`weight=400`) zusammengeführt. Die symmetrische Leerzeichenbereinigung funktioniert auch bei mehreren unterschiedlich formatierten Runs; tatsächlich gemischte Schriftformate bleiben erhalten. Der Textursprung des Zeichen-DC wird für `TextOutW` explizit links/oben festgelegt.

Tests: `test_lte_center_lane_v3453.py`, der erweiterte `test_lte_native.lpr` in `build.bat`. Changelog: `CHANGELOG-v3.4.53.md`; Bericht: `TESTREPORT-v3.4.53.md`. Windows-FPC-/GDI-Lauf muss auf dem Zielrechner erfolgen.

## Neu v3.4.52 – Falsches Schuh-Clipart (schwarze Raute)

`examples/Schuhe adidas.lbx` enthält die Font-Referenz `FONT,PTC Dingbats2,57906,51`. Auf der gemeldeten Windows-Installation wurde bisher eine schwarze Raute gezeichnet, obwohl P-touch Editor einen Schuhumriss anzeigt. Die bloße Existenz eines Schriftglyphs ist kein Beleg für das richtige Symbol.

Der Viewer prüft für **diese spezielle Kennung** jetzt das tatsächliche Bild des Fonts und probiert GDI-Unicode/Symbol-Zuordnungen sowie die LBX-Glyph-Ordnungsnummer. Ein ungeeigneter bzw. gefüllter quadratischer Glyph wird abgelehnt. Wird kein passender Schuhumriss gefunden, zeigt der Viewer den neutralen Platzhalter statt der Raute. Andere Cliparts werden nicht nach Form gefiltert.

Die Textgröße wurde nicht geändert: Die beiden Bildschirmfenster im Vergleich sind unterschiedlich stark vergrößert. Die tatsächliche Windows-Rasterung und der korrekte Originalschuh müssen auf einem PC mit installiertem Brother-Font überprüft werden. Die Brother-Fonts werden weiterhin **nicht** mitgeliefert.

[Änderungen](CHANGELOG-v3.4.52.md) · [Testbericht](TESTREPORT-v3.4.52.md)

## Neu v3.4.51 – FPC-3.2.2-Warnungen bereinigt

- Brother-Clipart-XML wird an allen neun gemeldeten Stellen explizit und
  verlustfrei von UTF-16 nach UTF-8 konvertiert, statt implizit über ANSI.
- Fünf `OleVariant`→`Boolean`-Konvertierungen im b-PAC-Host nutzen einen
  gemeinsamen Wrapper. Die sechs bekannten FPC-Inlining-Notes werden nur
  an den eigentlichen RTL-Operationen gezielt ausgeblendet. Globale
  Compilerwarnungen bleiben weiterhin eingeschaltet.
- Ansonsten keine Änderungen an Code128, Cliparts, Rendering oder Export.

[Änderungen](CHANGELOG-v3.4.51.md) · [Testbericht](TESTREPORT-v3.4.51.md)

---

## Neu v3.4.50 – echte P-touch-Code128-Referenz und kompakter B/C-Wechsel

Die vom Benutzer mit **P-touch Editor 5.4.018** korrigierte Datei
`examples/V34_Merge_Joined.lbx` ersetzt das frühere synthetische Beispiel
(das als `V34_Merge_Joined_Synthetisch.lbx` für Seriendrucktests erhalten bleibt).
Sie enthält sechs echte P-touch-Barcodeobjekte mit gespeicherter X-Modulbreite
`barWidth="0.8pt"` und den von P-touch normalisierten Objektbreiten.

Der **Code128** rechts von `Test` mit Inhalt `ABC12345` verwendete bisher
11 Codewörter, weil bei der ungeraden, fünfstelligen Ziffernfolge zu früh
von Zeichensatz B nach C gewechselt wurde. P-touch verwendet **10** Codewörter:
`START B / A / B / C / 1 / CODE C / 23 / 45 / CHECK 90 / STOP`.
Das ergibt **112 statt 123 X-Module**. Die gerenderte Balkenfolge stimmt damit
mit dem Screenshot aus P-touch Editor 5.4 überein (unabhängige Musterprüfung).

Die übrigen Barcode-Protokolle und ihre Prüfziffernalgorithmen sind nicht geändert.
Unter `examples/` liegen die Editor-LBX, eine Barcode-Referenz-PNG und die
112-Bit-Modulfolge; der Windows-Build enthält einen nativen Regressionstest.
**Windows-Compilerlauf/Total-Commander-Darstellung wurden hier nicht verifiziert.**

[Änderungen](CHANGELOG-v3.4.50.md) · [Testbericht](TESTREPORT-v3.4.50.md)

---

## Neu v3.4.49 – P-touch-Rahmen in `Postkasten_test(2).lbx`

Die echte Vorlage aus P-touch Editor 5.4.018 speichert ihren einfachen
rechteckigen Rahmen mit `angle="90"`, obwohl die sichtbaren Kanten auf
den **horizontalen Objektgrenzen** liegen. Bisher erzeugte die geometrische
Drehung zwei überlange senkrechte Linien statt des Rahmens um `Jon / Doe`.
Für einfache Vektorrahmen (`draw:frame`, `SIMPLE`, `style=0`, keine externe
Bilddatei) mit 90/270 Grad wird deshalb nur die Rahmengeometrie ungedreht
angezeigt. Textrotationen und andere Objekte sind nicht betroffen.

Das Originalbeispiel liegt in `examples/Postkasten_test(2).lbx`. Der native
Pixeltest `test_postkasten_frame_native.lpr` ist in `build.bat` eingebunden.
**250 Python-Tests bestanden.** Windows-Build/Total-Commander-Ansicht sind
noch nicht lokal geprüft.

[Änderungen](CHANGELOG-v3.4.49.md) ·
[Testbericht](TESTREPORT-v3.4.49.md)

---

## Neu v3.4.48 – experimentelle BEC-Auto2-Extraktion (ROM 213)

Die echte `KFZ Smart.lbx` referenziert `BEC,VEHICLE,10,Auto2`. In der
installierten P-touch-Editor-5.4-`Becdata.dll` ist **ROM-Ressource 213**
ein statisch plausibler Kandidat für die Kategorie. Der Viewer versucht nun
**nur für diesen Schlüssel** die Polygonextraktion mit Index **10** über
einen getrennten, mitgelieferten 32-Bit-Helfer. `build.bat` legt den Helfer
neben die WLX in `bin`. Die Brother-DLL wird **nicht mitgeliefert**.

Das Ergebnis wird nur als überprüftes BMP verwendet, sonst bleibt ein
Platzhalter. Der Helfer ist zeitbegrenzt, aber seine undokumentierte
Brother-Schnittstelle ist experimentell und kann abstürzen. **Die Zuordnung
213 → Auto2 ist noch nicht visuell bestätigt.** Auf Wunsch lässt sie sich
mit `Diagnose-Auto2-213.cmd` einzeln testen.

[Technische Details & Testanleitung](docs/BEC-Bridge-213.md) ·
[Änderungen](CHANGELOG-v3.4.48.md) ·
[Testbericht](TESTREPORT-v3.4.48.md)

---

## Neu v3.4.46 – installierte P-touch-Cliparts lokal finden

Clipart-Verweise werden über die lokale Brother-Installation aufgelöst. Die
Schriftdateien von P-touch Editor 5.4 oder bekannten 6.x-Verzeichnissen werden
bei Bedarf nur für den laufenden Prozess geladen. Relative BMP-/PNG-/JPEG-
Verweise aus erkannten Clipart-XML-Katalogeinträgen können dargestellt werden.
Fehlt eine Ressource, erscheint ein neutraler Platzhalter. Ein abweichender
Installationspfad lässt sich mit `LBX_PTOUCH_RESOURCE_DIRS` angeben.

**Einschränkung:** Echte P-touch-6-XML-Kataloge standen nicht für eine Prüfung
zur Verfügung. Proprietäre Brother-Vektorformate sind nicht vollständig
unterstützt. Ein vollständiger Windows-Build wurde hier nicht ausgeführt.

[Details](docs/Ptouch-Clipart-5.4-6.md) · [Änderungen](CHANGELOG-v3.4.46.md)

---

## Neu v3.4.45 – LBX-Einheiten zentral und kontextbezogen verarbeiten

`src/lbxunits.pas` liest Einheiten jetzt zentral mit invariantem Dezimalpunkt.
`lineSpace="15"` und `lineSpace="15%"` bedeuten beide 15 % der Schriftgröße;
`15pt` bleibt absolut. `pt`, `mm`, `cm`, `in` können in Längenfeldern verwendet
werden; Winkel sind Grad. QR-`eccLevel="15%"` bleibt eine QR-Korrekturstufe,
kein Textmaß. Eingaben mit unbekannter Einheit werden nicht geraten.

Die explizite Schreibweise `lineSpace="15%"` ist eine Viewer-Erweiterung;
sie ist **nicht** anhand einer vom P-touch Editor gespeicherten Vorlage
verifiziert. Die bisherige Semantik der vorhandenen Dateien bleibt erhalten.

**Tests:** 233 Python-Tests bestanden. Der neue native Pascal-Test
`test_units_native.lpr` ist in `build.bat` eingebunden, aber die Windows-
Kompilierung wurde hier nicht ausgeführt.

[Änderungen](CHANGELOG-v3.4.45.md) ·
[Einheiten-Dokumentation](docs/LBX-Einheiten.md) ·
[Testbericht](TESTREPORT-v3.4.45.md)

---

## Neu v3.4.44 – ESP32: fünf schwarze Punkte und korrigierte Textpositionen

Die originale `examples/ESP32 Weather Display.lbx` enthält fünf `Bookshelf Symbol 7`-Punktzeichen (Code 132). Der Viewer zentriert nun jeden runden Punkt innerhalb des originalen 14-pt-Symbolfeldes und unterdrückt die ersatzweise dargestellten Platzhalter-Kästchen. Der Zeilenabstand `lineSpace="15"` ist **15 %**, nicht 15 pt: `Boot`, `Reset` und `OTA` werden mit unverkleinerter 6,9-pt-Schrift und den Original-Abständen angeordnet.

**Tests:** 228 Python-Tests bestanden. Der native Pixeltest für fünf Punkte und die drei Textpositionen läuft auf Windows innerhalb von `build.bat`. Die Windows-Kompilierung wurde hier nicht ausgeführt. Nach dem Build Total Commander vollständig beenden und die aktuelle WLX-DLL laden.

[Änderungen](CHANGELOG-v3.4.44.md) · [Testbericht](TESTREPORT-v3.4.44.md)

---

## Neu v3.4.43 – Umlaut in der Datenquellen-Fehlermeldung

Bei fehlender CSV-/XLSX-Datei wurde `geprüft` im Hinweistext gelegentlich als `gepr?ft` dargestellt. Der lokalisierte Meldungstext wird nun ohne Windows-ANSI-Konvertierung in UTF-8-Bytes übertragen. Der **Dateipfad selbst war nicht beschädigt** und seine Auflösung ist unverändert.

Der FPC-3.2.2-Compilerfix aus v3.4.42 ist weiterhin enthalten. Vor einer Beurteilung der Punktsymbole in `ESP32 Weather Display.lbx` muss die neu gebaute DLL in Total Commander geladen sein; ein zuvor fehlgeschlagener Build aktualisiert die DLL nicht.

[Änderungen](CHANGELOG-v3.4.43.md) · [Testbericht](TESTREPORT-v3.4.43.md)

## Neu v3.4.42 – FPC-3.2.2-Kompilierfehler behoben

Im Parser der fünf Bookshelf-Symbol-7-Punkte wurde `Min(DotW,DotH)` mit zwei `Double`-Argumenten verwendet. FPC 3.2.2 meldete dabei `Incompatible type for arg no. 2: Got "Double", expected "LongInt"` (lbxcore.pas:1223). Die Berechnung verwendet nun einen direkten Vergleich beider Double-Werte, ohne Rundung oder Umwandlung zu Integer. Die Punkte bleiben gleich groß.

Die sechs `OleVariant`-Meldungen zu `lbx-bpac-host.lpr` sind Compiler-Notes und verhindern den Build nicht. Weitere Compilerfehler können erst durch einen erneuten Windows-Build ausgeschlossen werden.

[Änderungen](CHANGELOG-v3.4.42.md) · [Testbericht](TESTREPORT-v3.4.42.md)

## Neu v3.4.41 – P-touch-Font-Clipart im nativen Renderer

Die echte Datei `Schuhe adidas.lbx` verwendet `image:clipart` mit `FONT,PTC Dingbats2,57906,51`; **kein BMP** ist im LBX-ZIP enthalten. Diese Objekte wurden bisher bei der Parser-Objekterkennung ausgelassen. Jetzt werden sie als `lkClipart` eingelesen und ueber die in Windows vorhandene Symbolschrift gerendert. Nur bei tatsaechlich verfuegbarem passenden Gesicht und Zeichen wird die Schrift verwendet; P-touch braucht kein SDK. Wenn die Schrift nicht ueber Windows-GDI verfuegbar ist, zeichnet der Viewer bei genau diesem verifizierten Schuhsymbol einen einfachen Umriss als **naeherungsweisen Fallback**. Andere unbekannte Clipart-Referenzen werden nicht durch unpassende Ersatzzeichen ersetzt.

Die Tests nutzen die unveraenderte Original-LBX-Datei. Der native Windows-Test prueft Objektstruktur, Text und sichtbare dunkle Pixel im Schuhausschnitt. Der genaue Umriss aus P-touch ist nur mit der passenden Schrift verifizierbar. Keine Schriftdateien sind beigepackt.

[Änderungen](CHANGELOG-v3.4.41.md) · [Testbericht](TESTREPORT-v3.4.41.md)

## Neu v3.4.40 – Original-BMP bei P-touch-Beschnitt richtig skalieren

Bei `Portapack MDK.lbx` wurde die 16:9-Grafik bisher in ein schmaleres
Bildobjekt hineingestreckt. Jetzt wertet der native Renderer bei explizitem
`image:trimming` die gespeicherte `image:orgPos`-Geometrie aus und beschneidet
den ursprünglichen Bildausschnitt auf das Objekt. Seitenverhältnis und
Ausrichtung bleiben erhalten. Die Vorschau, der native Thumbnail-Pfad und
der PNG-Export nutzen die korrigierte Zeichenroutine.

Unter `examples/Portapack MDK.lbx` liegt die **unveränderte P-touch-Datei**.
`Portapack-MDK-Beschnitt-Referenz.png` zeigt die aus den Bildkoordinaten
berechnete Referenz. Der Windows-Nativtest ist in `build.bat` eingebunden.

[Änderungen](CHANGELOG-v3.4.40.md) · [Testbericht](TESTREPORT-v3.4.40.md)

## Neu v3.4.39 – originale Punktsymbole bei ESP32 Weather Display

`examples/ESP32 Weather Display.lbx` enthält fünf P-touch-Symbole der Schrift
`Bookshelf Symbol 7`, Code `132`. Die native Vorschau rendert diese nun als
**runde, gefüllte Punkte** aus den in der LBX gespeicherten Objektpositionen
und -breiten, anstatt aus dem 14pt hohen Symbolfeld Rechtecke zu machen.
Die normalen Beschriftungen `Boot`, `Reset` und `OTA` und die vorherigen
Webdings-/Wingdings-Fixes bleiben unverändert.

**Windows-Test:** Total Commander schließen, neue ZIP entpacken, `build.bat`
ausführen, anschließend `examples/ESP32 Weather Display.lbx` öffnen.
Fünf schwarze Punkte und die Beschriftungen mit P-touch Editor vergleichen.
Der native Win64-Build konnte hier nicht ausgeführt werden.

[Änderungen](CHANGELOG-v3.4.39.md) · [Testbericht](TESTREPORT-v3.4.39.md)

---

## Neu v3.4.38 – korrekte Ausrichtung von P-touch-QL-Etiketten

Bei echten P-touch-Dateien mit `orientation="portrait"` verwendet der Viewer
nun die richtige X/Y-Seitengeometrie. `100Ω Kohleschicht.lbx` erscheint
quer mit 62,0 × 25,0 mm statt hochkant. Die 62-mm-Medienbreite bleibt
für die Druckerprüfung erhalten; der separat gespeicherte Querdruck wird
nicht mit der Medienbreite verwechselt. Ohne Attribut oder bei
`orientation="landscape"` bleibt die bisherige Seiteninterpretation bestehen.

**Test:** ZIP in neuen Ordner entpacken, `build.bat` unter Windows ausführen,
Total Commander neu starten und `examples\100Ω Kohleschicht.lbx` öffnen.
Das Projekt wurde nur mit Python-Tests validiert, nicht nativ unter Windows.

[Änderungen](CHANGELOG-v3.4.38.md) · [Testbericht](TESTREPORT-v3.4.38.md)

---

## Neu v3.4.37 – verlängerte Schutzbalken bei EAN/UPC

**EAN-13, EAN-8, UPC-A und UPC-E** haben im Original unterschiedlich lange Balken. Die *Guard Bars* (Start-, Mittel- und Endmarkierungen) werden nun am unteren Ende **um fünf X-Module** verlängert dargestellt. Bei **UPC-A** betrifft dies zusätzlich die erste und letzte codierte Ziffer. Die Bitfolge, die Prüfziffern, die Höhe des LBX-Objekts und der nutzbare Druckbereich werden nicht verändert. Code 39, Code 128, GS1-128 und QR-Codes behalten ihre bisherige Darstellung.

**Historischer Hinweis (vor v3.4.50):** Die damalige `V34_Merge_Joined.lbx` war synthetisch. Sie wurde inzwischen nach `V34_Merge_Joined_Synthetisch.lbx` umbenannt. Die heutige Datei `V34_Merge_Joined.lbx` wurde vom Benutzer mit **P-touch Editor 5.4.018** gespeichert und ist die neue Referenz für Code128. Der vorher als `Ungültig` gezeigte synthetische Datensatz darf nicht als echtes P-touch-Verhalten interpretiert werden.

Tests: **203 Python-Tests bestanden**. Der native Pascal-Test wurde um alle vier EAN/UPC-Guard-Masken und negative Kontrollen für Code 128/GS1-128 erweitert; der Windows/FPC-Build kann nur unter Windows ausgeführt werden.

[Änderungen](CHANGELOG-v3.4.37.md) · [Testbericht](TESTREPORT-v3.4.37.md)

---

## Neuerungen v3.4.36 – Endlosband-Layout

Bei Endlosband nimmt der Viewer die tatsächliche verwendete Länge aus `style:backGround` (nicht die maximale Länge aus `style:paper`). Längere Textobjekte mit `textControl autoLF=true` werden innerhalb der Textfeldbreite umbrochen. CR, LF und CRLF gelten als Zeilenumbrüche. Eine kurze Beschriftung wie `Mobil-funk` wird weiterhin mit der bisherigen kurzen Bindestrich-Regel behandelt.

Zum Testen: ZIP vollständig in einen neuen Ordner entpacken, Total Commander vor dem Ersetzen der WLX-Datei schließen, `build.bat` ausführen und die Endlosband-Vorschau mit P-touch Editor vergleichen. Die tatsächlichen Maße stehen unten im Infokasten.

Der Vergleich `Blei-Akku.lbx` beruht bislang nur auf dem Screenshot; ohne die Original-LBX ist die exakte Darstellung nicht bestätigt. Der neue GDI-Regressionslauf ist in `build.bat` enthalten, konnte hier aber noch nicht unter Windows gestartet werden.

# Neu v3.4.35 – P-touch-Symbole ohne b-PAC SDK

Die originale `examples/Audioumschalter.lbx` enthält drei `draw:symbol`-Objekte innerhalb **eines mehrzeiligen Textfeldes** (zweimal Webdings `175`, einmal Wingdings `58`). Der native Renderer liest die originalen Symbolcodes jetzt ein, wählt die richtige Windows-Symbolschrift und behält die ursprünglichen Zeilen und unterschiedlichen Schriftgrößen bei. Damit sollen die bisher sichtbaren Kästchen durch Musiknoten und das Computersymbol ersetzt werden.

Der Fix benötigt **kein Brother SDK**. Voraussetzung sind die Windows-Schriftarten **Webdings und Wingdings**. Der Original-LBX-Inhalt wird nicht verändert.

**Tests:** 195 Python-Tests bestanden; der neue native Windows-Test läuft innerhalb von `build.bat`, wurde hier jedoch noch nicht unter Windows ausgeführt. Nach dem Build die Datei in Total Commander erneut öffnen und mit P-touch Editor vergleichen. [Changelog](CHANGELOG-v3.4.35.md) · [Testbericht](TESTREPORT-v3.4.35.md).

---

# Neu v3.4.33 – GS1-128-Balkenbreite bei fehlendem `barWidth`

Die lange Barcode-Zone der synthetischen Vorlage `GS1_HRI_RIGHT.lbx` enthält
keine physikalische `barWidth`-Angabe. Der frühere Renderer dehnte deshalb die
134 Module auf die fast vollständige Objektbreite aus. Bei EAN128, GS1-128 und
UCC/EAN-128 ohne `barWidth` wird nun eine konservative Standard-Modulbreite
von **0,7 pt (ca. 0,247 mm)** als Obergrenze verwendet, ohne die ursprüngliche
Objektbreite oder die Textausrichtung umzuschreiben. Eine im LBX angegebene
`barWidth` hat weiterhin immer Vorrang.

Wichtig: Der 0,7-pt-Wert ist eine Annäherung aus dem Screenshot, **kein
validierter P-touch-Standardwert**. Die unter `examples/GS1_HRI_*.lbx`
liegenden automatischen Testvorlagen sind keine verifizierten, mit P-touch
Editor gespeicherten Originaldateien. Die Screenshot-Ansicht aus P-touch
verwendet außerdem einen anderen Drucker (QL-500 statt PT-2430PC) und damit
möglicherweise andere Medien-/Autolängen-Einstellungen. Exakte physische
Übereinstimmung muss an einer authentischen P-touch-Datei überprüft werden.

- 188 Python-Tests bestanden.
- Windows/FPC und native Pixeltests sind in `build.bat` enthalten, aber hier
  nicht ausgeführt.

[Änderungen](CHANGELOG-v3.4.33.md) · [Tests](TESTREPORT-v3.4.33.md)

---

# Neu v3.4.32 – Datenquelle wählen / Renderer-Untermenü

Mit **Datenquelle wählen …** im Kontextmenü kannst du bei Etiketten mit Seriendruckfeldern eine CSV-/Excel-Datei laden. Ohne Felder ist der Eintrag ausgegraut. Die Auswahl gilt nur für das aktuelle Viewer-Fenster, wird bei **F5** beibehalten und ändert **nicht** die gespeicherte LBX-Datei. Die Datenquelle muss die für die Felder benötigten Spalten enthalten; XLSX-Dateien sollten die im Etikett hinterlegte Tabellenblattbezeichnung behalten.

Die Renderer-Einstellungen stehen jetzt im Untermenü **Renderer → Automatisch / Nativ (FPC) / SDK (Brother b-PAC bevorzugt)**. Die bisherige INI-Einstellung bleibt wirksam. Deutsch, Englisch, Russisch und Ukrainisch sind aktualisiert.

[Änderungen](CHANGELOG-v3.4.32.md) · [Tests](TESTREPORT-v3.4.32.md)

---

# Neu v3.4.31 – P-touch-Gültigkeit der Testdaten

**Korrektur:** Die automatisch erzeugten Kreis-/QR-/CSV-Beispiele sind interne LBXViewer-Testfixtures. Sie waren nie durch P-touch Editor validiert. In `ptouch-reference/` liegen eine bytegenau unveränderte Editor-Originaldatei und ein daraus abgeleiteter **unverifizierter** QR-/Bild-/Text-Prüfkandidat. Erst nach erfolgreichem Öffnen, Speichern und erneutem Öffnen im P-touch Editor gilt ein Prüfkandidat als kompatibel. Details: [P-touch-Prüfung](ptouch-reference/README-DE.md). An der Viewer-Renderlogik wurde in diesem Release nichts geändert.

# Neu v3.4.30 – vollständigere Miniaturen ohne Verzerrung

- Bei Bild/QR/Text-Etiketten (etwa `series_utf16_surrogates.csv.lbx`) werden **Kreissymbol, QR-Code und aufgelöster Seriendrucktext** nebeneinander als kompakte Miniatur gezeichnet. Das eingebettete quadratische BMP wird **proportional** dargestellt; der QR-Code bleibt quadratisch.
- Bei zu kleinen Miniaturmaßen bleibt die komplette, seitenverhältnisgetreue Etikettenansicht als Rückfall. Druck- und Exportlayout sind unverändert.
- **Wichtig nach der Installation:** Total Commander vollständig beenden und den Thumbnail-Cache neu aufbauen/leeren, sonst können die alten Miniaturen mit nur dem Kreis weiter sichtbar sein.
- 177 Python-Tests bestanden; die neue native Windows-Pixelprüfung ist in `build.bat` eingebunden, aber hier noch nicht ausgeführt.

[Änderungen](CHANGELOG-v3.4.30.md) · [Tests](TESTREPORT-v3.4.30.md)

---

# Neu v3.4.29 — FPC-Kompilierfehler `FBold` behoben

- Der Fehler `lbxrender.pas(313,46) Error: Identifier not found "FBold"` aus v3.4.28 ist korrigiert.
- Der Barcode-HRI-Zweig gibt nur seine eigene Schrift frei; die fette Schrift des Infokastens wird im richtigen `finally`-Block freigegeben.
- Das Layout aus v3.4.28 und die früheren Funktionen bleiben erhalten.
- **169 Python-Tests bestanden.** Windows-Build muss noch unter FPC 3.2.2 geprüft werden.

[Änderungen](CHANGELOG-v3.4.29.md) · [Tests](TESTREPORT-v3.4.29.md)

---

# Neu v3.4.28 — Material in Zeile 3, Abstand und fette Überschriften

- Unten links steht die **Materialinformation nun in der dritten Zeile**:
  geändert, gedruckt, Material, Höhe/Länge, Drucker.
- **Höhe** und **Länge** werden mit getrennten GDI-Textläufen gesetzt;
  dazwischen liegen mindestens 20 Pixel Abstand statt mehrdeutiger
  Leerzeichen aus den übersetzten Sprachdateien.
- Die Feldnamen im Infokasten sowie CSV-/Excel-Spaltenüberschriften sind
  **fett**; Werte und Datensatzzeilen bleiben normal formatiert.
- Der erweiterbare Infobereich, die kompakte Bild/QR/Text-Miniatur und die
  Theme-/Sprachumschaltung bleiben erhalten. Die Änderungen betreffen nur
  die Metadaten-Darstellung, nicht das Etikett oder die Druckausgabe.
- 166 Python-Regressionstests bestanden; Win64/FPC- und GDI-Darstellung
  müssen auf dem Zielsystem überprüft werden.

[Änderungen](CHANGELOG-v3.4.28.md) · [Tests](TESTREPORT-v3.4.28.md)

---

# Neu v3.4.27 — erweiterte Miniaturen, verschiebbare Trennlinie, Materialtext

- Miniaturen für verknüpfte Etiketten mit Bild, QR/Barcode und Text zeigen
  die drei Elemente nebeneinander, auch wenn das Etikett sehr schmal ist.
  Die Miniatur dient zur Wiedererkennung, nicht als druckgenauer Layout-Beweis.
- Den unteren Info-/Seriendruckbereich an seiner **oberen Trennlinie** mit
  gedrückter Maustaste nach **oben** ziehen. Mindesthöhe bleibt **110 Pixel**,
  zusätzliche Höhe zeigt weitere Datensätze.
- Der Zusatz `(Material unbekannt)` entfällt, wenn kein tatsächlicher
  Materialname in der Datei oder in einer expliziten Zuordnung gespeichert ist.
  Bekannte Druckerfamilien und Bandbreiten werden weiter gezeigt.
- **162 Python-Tests bestanden.** Für den Windows-FPC-Build und die reale
  Vorschau in Total Commander ist eine Windows-Prüfung erforderlich.

[Änderungen](CHANGELOG-v3.4.27.md) · [Tests](TESTREPORT-v3.4.27.md)

---

# Neu v3.4.26 – Seriendruck-Spalten wieder zuverlässig erkennen

- Die Spaltensuche arbeitet durchgehend in `UnicodeString`; sie umgeht
  implizite ANSI-Konvertierungen und vergleicht UTF-16-Feldnamen.
- Bei Datenquellen mit den Spalten `Trupp` und `MZA` darf ein vorhandenes
  `MZA` nicht als fehlend gemeldet werden. Echte fehlende Spalten werden
  weiterhin gemeldet.
- Die **Off-by-one-Korrektur** aus v3.4.19 bleibt unangetastet:
  gespeicherter Datensatz `12` entspricht Zeilenindex `11`.
- 158 Python-Tests bestanden; der erweiterte Windows-FPC-Test wird durch
  `build.bat` ausgeführt und muss auf dem Zielsystem noch bestätigt werden.

[Änderungen](CHANGELOG-v3.4.26.md) · [Tests](TESTREPORT-v3.4.26.md)

---

# Neu v3.4.25 – Einpassen mit C, Dark/Light/Automatic und i18n

- Einpassen: **C** statt **0** (Strg+C bleibt frei).
- Unter **Darstellung / Appearance**: Automatic (Windows), Light, Dark.
  INI: `[Appearance] Theme=Automatic` (Standard).
- Unter **Sprache / Language**: Automatic, English, Deutsch, Русский,
  Українська. INI: `[Localization] Language=auto` (Standard);
  `en`, `de`, `ru`, `uk`, Sprachcodes mit Regionen (z.B. `de-DE`) unterstützt.
- Die UTF-8-Übersetzungen liegen in **`language/en.ini`**, `de.ini`,
  `ru.ini`, `uk.ini`; fehlende/unerwartete Einträge fallen auf **Englisch**
  zurück. Die Etikettenfläche, PNG und der Druck bleiben unverändert weiß.
- Beim Windows-Build werden die Sprachdateien nach `bin/language` kopiert
  und die vorhandene `bin/lbxview.ini` beibehalten.
- 153 Python-Tests bestanden. Windows-FPC-Build noch nicht verifiziert.

[Änderungen](CHANGELOG-v3.4.25.md) · [Tests](TESTREPORT-v3.4.25.md)

---

## Aktualisierung v3.4.24 — W110 im zweizeiligen Etikett korrekt zentrieren

Beim Originaletikett `Label Kabel LTE.lbx` überlappte der zentrale Text `W110   I   W110` die linke zweizeilige Beschriftung `Mobil-` / `funk`. Die Vorschau ignoriert nun beim Zentrieren **gleich viele äußere Leerzeichen**, ohne die Originaldaten zu verändern. Die beiden seitlichen zweizeiligen Beschriftungen und der W250-Fall bleiben vom Eingriff unberührt.

**Tests:** 145 Python-Tests erfolgreich; die Windows-GDI-Tests wurden erweitert, können hier ohne Windows/FPC aber nicht ausgeführt werden. Bitte `build.bat` unter Windows ausführen und den W110-Vergleich mit P-touch Editor prüfen. Siehe [Changelog](CHANGELOG-v3.4.24.md) und [Teststand](TESTREPORT-v3.4.24.md).

---

## Aktualisierung v3.4.23 — Native Windows-Tests werden am richtigen Ort gestartet

Der Screenshot zeigte den Fehler `test_shared_open_native.exe` wurde nicht gefunden. `build.bat` erzeugt die Test-EXE jetzt ausdrücklich in `bin\` und startet sie mit dem vollständigen relativen Pfad. Vorherige Testdateien werden entfernt und der Erfolg der Ausgabe geprüft, damit keine alte Test-EXE für ein falsches positives Ergebnis sorgt. Siehe [Änderungsliste](CHANGELOG-v3.4.23.md) und [Teststand](TESTREPORT-v3.4.23.md).

## Aktualisierung v3.4.22 — Compilerwarnungen gezielt behoben

Die 28 im Windows-FPC-Build v3.4.21 gemeldeten Warnungen wurden **im Quellcode**
behandelt: UTF-16-Trimmung und CR-Entfernung ohne ANSI-Zwischenschritt,
explizite UTF-8-Warntexte und Unicode-Zahlenformate, Initialisierung des
verwalteten `TLBXRuns`-Ergebnisses sowie 64-Bit-Systemtick-Zähler. Sechs
ungenutzte lokale Variablen wurden entfernt. Es gibt keine pauschale
Warnungsunterdrückung. Die Änderungen stehen in `CHANGELOG-v3.4.22.md`.

**Wichtig:** Python-Tests validieren Verträge/Referenzdaten, aber keine
Windows-GDI-Laufzeit. Ein Windows-FPC-3.2.2-Build und die Bestätigung **0
Compilerwarnungen** stehen noch aus. `build.bat` im entpackten Verzeichnis
starten, danach `findstr /n /c:"Warning:" build-v3.4.22.log` (bei umgeleitetem
Build-Log). Eine fehlerfreie Kompilierung garantiert keine allgemeine
Sicherheitsfreiheit; Drucken und Brother COM müssen real getestet werden.

[Änderungen](CHANGELOG-v3.4.22.md) · [Teststand](TESTREPORT-v3.4.22.md)

---

## Aktualisierung v3.4.21 — UTF-16/UTF-8-Daten ohne ANSI-Konvertierung

Die Tabelle und der Seriendruck speichern CSV-/Excel-Zellen nun bis zur
GDI-`DrawTextW`-Ausgabe durchgehend als `UnicodeString`. Das verhindert den
bisher gemeldeten Fehler `Gr????e` bei UTF-16/UTF-8-Dateien. Der Windows-Build
ist noch ausstehend. `build.bat` verhindert eine scheinbar erfolgreiche
Installation einer alten/gesperrten WLX-Datei.

[Details](CHANGELOG-v3.4.21.md)

---

## Aktualisierung v3.4.20

FPC-3.2.2-Kompilierfix in `src/lbxsharedio.pas`: doppelte Deklarationen aus `LBXSharedFileSize` entfernt. Details: `BUILD_FIX_3_4_20.md`.

**Version 3.4.19 – Seriendruck-Datensatzindex:** Beim Laden wird die 1-basierte P-touch-Angabe `currentRecord` genau einmal in den internen 0-basierten Index umgerechnet. `0` und `1` starten beim ersten Datensatz, `12` beim zwölften. Navigation und Druck bleiben intern 0-basiert. Siehe [CHANGELOG-v3.4.19.md](CHANGELOG-v3.4.19.md).

# LBXViewerWLX v3.4.18 – Unicode in CSV-/Excel-Seriendruck

Neu: UTF-16LE/BE, UTF-8 und Excel-Texte bleiben über CSV-Lader,
Tabellendarstellung und die aufgelösten Seriendruckobjekte unverfälscht.
Beispiel `Series_CSV_UTF16.lbx`: **Grüße** statt **Gr????e**.

[Details](CHANGELOG-v3.4.18.md) · [Testprotokoll](TESTREPORT-v3.4.18.md)

---

# LBXViewerWLX v3.4.17 – W110-Schriftgewicht

Im Mitteltext der originalen P-touch-Datei `Label Kabel LTE.lbx` sind alle sichtbaren Buchstaben und Ziffern **normal** (`weight=400`). Nur reine Leerzeichenläufe tragen 700. v3.4.17 führt gleich formatierte sichtbare Textläufe vor dem GDI-Zeichnen zusammen, statt optische Artefakte an den Abschnittsgrenzen zu riskieren. Die beiden äußeren `Mobil-funk`-Objekte bleiben fett. Siehe `CHANGELOG-v3.4.17.md`.

# LBXViewerWLX v3.4.16 – Barcode- und QR-Korrekturen

**Aktueller Stand:** GS1-128 und die weiteren linearen Barcodes beachten jetzt die gespeicherte `barWidth`-Größe und die zugehörigen Ruhezonen; QR-Code respektiert `cellSize` und `margin`. UPC-E-Parität wurde korrigiert, Code39-Verhältnis 1:2 ergänzt.

[Änderungsliste](CHANGELOG-v3.4.16.md) · [Testbericht](TESTREPORT-v3.4.16.md) · [Windows-Testanleitung](MANUAL_BARCODE_TEST.md)

# LBXViewerWLX v3.4.15 – FPC-Kompilierfix

Korrektur für `lbxdata.pas(244,5)`: `TXlsxArchive.Snapshot` jetzt vor den Methoden. Siehe [BUILD_FIX_3_4_15.md](BUILD_FIX_3_4_15.md).

# LBXViewerWLX v3.4.12 – Lesen bei geöffneten Dateien

**Neu:** LBX, verknüpfte Excel-/CSV-Dateien und optionale BMPs werden nur lesend mit Windows-Share-Flags `READ | WRITE | DELETE` geöffnet. Für ZIP-Dateien verwendet die FCL einen stabilen in-memory-Schnappschuss über die `TUnZipper`-Stream-Callbacks. Öffne `CHANGELOG-v3.4.12.md` für Details.

**Grenze:** Wenn der andere Prozess das Lesen ausdrücklich verbietet (exklusive Sperre), kann Windows keinen parallelen Zugriff gewähren. b-PAC ist optional und erhält nur eine temporäre Kopie des Labels; das Original wird auch dafür ausschließlich lesend geöffnet. Bei COM-Problemen ist Native der Rückfall.

**Windows-Test:** `build.bat` führt `test_shared_open_native.exe` aus, bevor weitere Tests gestartet werden.

---

# LBXViewerWLX v3.4.11 – EAN128 / GS1-128

**Neu:** EAN128, GS1-128 und UCC/EAN-128 werden als echte Code128-Symbole mit verpflichtendem initialem FNC1 sowie automatischen GS1-Trennzeichen gezeichnet. Beispiel: `(01)09501101530003(17)250101` oder `(10)LOT12(21)SN7`. Unterstützte AIs, Rohdatensyntax, Beispiele und Grenzen: [CHANGELOG-v3.4.11.md](CHANGELOG-v3.4.11.md).

**Testen:** `python -m pytest -q tests` prüft die Referenzvektoren/Quellen; **`build.bat` unter Windows** kompiliert den neuen **nativen GS1-Test** mit FPC und vergleicht die echten Modulmuster. Eine erfolgreiche Windows-Kompilierung ist hier noch nicht bestätigt. Ohne LCL, keine neuen Laufzeitabhängigkeiten.

---

# LBXViewerWLX v3.4.7 – korrekte LBX-Objektebenen

**Wichtige Korrektur:** Textobjekte werden nicht mehr wegen geometrischer Überlappung zusammengeführt. Jedes Objekt behält seine Position, Ausrichtung, Transparenz und Ebene (XML-Z-Reihenfolge). Die in v3.4.5 eingeführte künstliche Verknüpfung `FK ` + `MZA` wurde entfernt. Die P-touch-Vorlage `FK.lbx` verdeckt Teile des hinteren Feldes bewusst mit dem weißen Textobjekt `FK` darüber; diese Überdeckung wird jetzt reproduziert. Gültige leere Datenfelder bleiben leer.

Eingebettete `text:innerObject`-Felder in **einer** Textzeile (z.B. `FK (` + Feld + `)`) werden weiterhin inline ersetzt und gemeinsam im **gleichen** Objekt ausgerichtet. Ausführliche Analyse und Tests: [FIX_3_4_7_OBJECT_LAYERS.md](FIX_3_4_7_OBJECT_LAYERS.md).

# Historische Beschreibung v3.4.5 (durch v3.4.7 ersetzt)

Diese Version baut auf v3.4.4 (FK/MZA, Inline-Felder und Transparenz) auf.

- **FK.lbx:** Die überlappenden Objekte `MZA` (hinten) und `FK ` (vorn) werden nur bei passender Geometrie als **eine sichtbare Textzeile** gezeichnet. Die vollständige Datenbankzeichenfolge steht nach `FK `; sie wird nicht hinter der Deckfläche abgeschnitten.
- **Ebenen:** Die Umstellung greift ausschließlich bei **zwei direkt aufeinanderfolgenden**, nicht transformierten, vertikal überlappenden Textobjekten mit identischem linken Rand; das vordere Objekt muss eine deckende Fläche haben und das hintere eine Datenbankzuordnung. In anderen Fällen bleibt die normale LBX-Zeichenreihenfolge bestehen.
- **Leere Felder:** Sind ein gültiger Datenwert. Im Etikett erscheint kein Wert und in der Tabelle keine Warnung aufgrund der Leere allein.
- **InnerObjects:** Feste Klammern plus eingebettetes `text:innerObject` bleiben eine einzige formatierte Textzeile.
- **Tests:** `pytest -q tests` sowie `build.bat` auf Windows. Der native GDI-Test `tests/test_fk_mza_native.lpr` vergleicht die sichtbare Breite des Etiketts mit gefülltem und leerem Feld.
- **Beispiel:** `examples/FK_Hallo13.lbx` und `examples/FK_Hallo13.xlsx` sind **synthetische Regressionstests**: die Original-XLSX enthält `Hallo12` als letzten nichtleeren MZA-Wert und kein `Hallo13`.

**Build:** `build.bat` unter Windows mit Free Pascal 3.2.2+. Das aktuelle Paket ist Quellcode, keine unter Windows verifizierte DLL. Das Projekt verwendet keine LCL.

---

# LBXViewerWLX v3.4.3 – Brother-Inline-Felder

**NEU:** Fix für echte P-touch-5-Seriendruckfelder (`text:innerObject`, U+007F) und unveränderte Positionen. Anleitung: [FIX_3_4_3_TRUPPX.md](FIX_3_4_3_TRUPPX.md).

# LBXViewerWLX v3.4.2 — Seriendruck-Fix

Ergänzung zu v3.4.1: Mehrere Tabellenplatzhalter und feste Texte innerhalb eines Textobjekts werden gemeinsam aufgelöst und positioniert. Neue GDI- und Feldzuordnungstests. Details in `BUILD_FIX_3_4_2.md`.

# v3.4.1 FPC-Kompilierkorrektur

Siehe [BUILD_FIX_3_4_1.md](BUILD_FIX_3_4_1.md). v3.4.1 korrigiert vier versehentlich eingeschobene Funktionsköpfe in `src/lbxcore.pas` und die daraus folgenden Parserfehler in FPC 3.2.2. Die Windows-Kompilierung ist noch nicht verifiziert.

# LBXViewerWLX v3.4 – neue Funktionen

**Neu:** Code39, Code128, EAN-13/EAN-8, UPC-A/UPC-E; gedrehte und gespiegelte Objekte, verschachtelte Gruppenrotation; Schriftfarbe, Unterstreichung, Durchstreichung, Text-Effekte; kombinierte P-touch-Datenbankfelder; erklärende Materialanzeige und optionale Benutzerzuordnung. **Alles weiterhin ohne LCL.**

Siehe [`CHANGELOG-v3.4.md`](CHANGELOG-v3.4.md) und [`TESTREPORT-v3.4.md`](TESTREPORT-v3.4.md).

## Kurzanleitung Windows

1. Mit **Free Pascal 3.2.2+** (Windows x64) im Projektverzeichnis `build.bat` ausführen.
2. Erst wenn alle nativen Tests erfolgreich sind, `bin\lbxview.wlx64` in Total Commander registrieren. Für Thumbnails Lister-Plugin-Vorschau aktivieren.
3. F3-Vorschau/Thumbnails an `examples\V34_Barcodes_Groups_Style_Merge.lbx` testen. Die Datenquelle `examples\v34-data.csv` liegt daneben. Pfeil nach unten wechselt von „Anna Beispiel“ zu „Max Mueller“ und auch den Code128-Feldwert von `ABC12345` zu `12345678`.
4. Gedrehte Objekte separat mit `examples\V34_Rotated_Only.lbx` testen. In der neuen nativen Testsuite wird überprüft, dass die GDI-Vorschau tatsächlich sichtbare Pixel enthält.
5. Unter Windows optional `set LBX_MATERIAL_MAP=C:\Pfad\materialien.ini` setzen (siehe `materials-example.ini`), wenn für einen lokalen Drucker konkrete Materialnamen bekannt sind. **Ohne solche verifizierten Angaben bleiben TZe-/HGe-Typ und Farbe unbekannt.**

**Testergebnis dieser Entwicklungsumgebung:** `python -m pytest -q tests` → **49 bestanden**. Die eigentliche Windows-Kompilierung und GDI-Ausgabe können hier nicht ausgeführt werden und müssen unter FPC/Total Commander geprüft werden.

---

# LBXViewerWLX v3.3 – Datenquellen- und Seriendruckansicht

Die v3.3-Erweiterung zeigt im **Total-Commander-F3-Fenster** das unverändert
maßhaltige Etikett **oberhalb** des festen 110-Pixel-Informationsbereichs.
Unter dem Etikett stehen links (50 % Fensterbreite) die fünf Metadatenzeilen,
rechts (50 %) die mit der LBX-Datei verknüpfte Datentabelle.
**Miniaturansichten und exportierte PNG-Dateien enthalten weiterhin nur das
Etikett, nicht die Metadaten oder Tabelle.**

## Datenquellen: CSV ist ein offizielles Brother-Feature

P-touch Editor 5 und 6 unterstützen CSV und Excel als Seriendruck-Datenquellen.
Dokumentation (P-touch Editor 6):
https://download.brother.com/pub/com/p-touch6-help/en-US/help/database_linkage/definition_and_sample/definition_and_sample.html

**Native Unterstützung im Viewer:** `.csv`, `.txt`, `.tsv` (Trennzeichen
Komma/Semikolon/Tabulator; BOM UTF-8/UTF-16, ANSI-Fallback), `.xlsx` und `.xlsm`
(OpenXML-Tabellen direkt aus ZIP, ohne Excel und ohne LCL). Für ältere binäre
`.xls`-Dateien zeigt v3.3 einen klaren Hinweis statt eine falsche Tabelle;
`Access .mdb/.accdb` wird derzeit nicht gelesen. Brother selbst kann diese
Formate unter Windows teilweise ebenfalls öffnen – **dies ist keine Zusage,
dass unser Renderer sie unterstützt.** XLSX-Formeln verwenden den in der
Datei gespeicherten berechneten Zellwert; Werte ohne Cache und fehlende
Arbeitsblätter werden gemeldet. Formatiert angezeigte Excel-Datums-/Zahlenwerte
werden noch nicht anhand sämtlicher Office-Zellformate nachgebildet.

**Datensatznavigation im F3-Viewer:**

- `↑` / `↓`: vorheriger / nächster Datensatz. `Bild↑` / `Bild↓` springt je drei,
  `Pos1` / `Ende` zum ersten / letzten Datensatz.
- `←` / `→`: Tabelle spaltenweise horizontal verschieben.
- Mausrad **über der unteren rechten Tabelle**: Datensatz wechseln; mit
  Shift oder horizontalem Mausrad Spalten bewegen.
- Klick auf eine sichtbare Datenzeile markiert diese; Pfeile rechts in der
  Tabelle ermöglichen die gleiche Navigation.
- Das **ausgewählte Tabellenrecord erscheint sofort im Etikett darüber**.
  Lange Texte werden innerhalb ihres Textobjekts verkleinert und beschnitten,
  statt Nachbarobjekte zu überzeichnen.
- `F5` oder Rechtsklick → **Datenquelle neu laden**, wenn sich CSV/Excel
  seit dem Öffnen verändert hat.
- Strg + Mausrad über dem Etikett zoomt weiterhin; Ziehen/Scrollen bewegt
  nur die obere Etikettenfläche.

**Fehlermeldungen:** Nicht auffindbare Dateien, unlesbare Dateien, fehlende
Tabellenblätter, ungültige CSV-Zeichenfolgen, nicht vorhandene Spalten und
Dateien ohne Datensätze werden im rechten Fußbereich angezeigt. Die LBX-Datei
bleibt zur Ansicht geöffnet; der gespeicherte Text ist weiter sichtbar, wenn
keine aktuellen Seriendruckdaten verwendet werden können. Relative Datenquellen
werden zunächst neben der LBX gesucht, bei abweichenden alten Originalpfaden
dann auch anhand des Dateinamens. Keine Änderung der originalen LBX/CSV/XLSX.

**Wichtig für b-PAC:** Bei jeder verknüpften Datenquelle verwendet der Viewer
absichtlich den nativen FPC-Renderer, selbst wenn die Quelldatei fehlt.
Ein b-PAC-Bild des ursprünglichen Datensatzes würde sonst einen anderen Inhalt
als die markierte Tabellenzeile zeigen.

**Neu für Tests:** `examples/Series_*.lbx`, `.csv`, `.xlsx`,
`tests/test_series_native.lpr` und `tests/test_series_v33.py`. `build.bat`
baut und startet die nativen Seriendruck-Tests. Die Bilder `preview-series-*.png`
sind ausschließlich **Python-Referenzdarstellungen**, keine Screenshots einer
Windows-WLX-Laufzeit.

## Status

- Python-Format-/Quellcode-Tests: **34 bestanden** (auf dieser Entwicklungsumgebung).
- Windows-FPC-3.2.2-Build und echte WLX-GDI-/Excel-Integrationstests:
  **noch nicht ausgeführt**; mit `build.bat` unter Windows prüfen.
- Die interaktive Tabelle und die Excel-Datenverarbeitung sind vorerst nicht mit
  realen, komplexen P-touch-5-/6-Seriendruckdateien auf mehreren Computern
  abgeglichen. Es können weitere Datenbank-Mapping-Varianten existieren.

---

# LBXViewerWLX v3.2.2 – White thumbnail fallback and diagnostics

**Symptom:** Total Commander displays a blank or almost empty white thumbnail for .lbx files. The previous auto renderer accepted any structurally valid Brother BMP, including an all-white render. The native tests checked bitmap size and white corners but not whether there is any drawn content.

**Changes:** `BrotherImageHasInk` renders a small preview and inspects its resulting RGB pixels. If it is blank/nearly blank and the parsed document contains objects, both the F3 viewer and WLX thumbnail path fall back to native GDI rendering. No LCL. The pixel inspection intentionally uses a dark-pixel threshold to avoid accepting a few stray gray pixels as content. This heuristic can reject legitimately very faint labels; switch to `Mode=Brother` for diagnosis if needed (the blank guard still operates).

**Fast isolation:** Set `Mode=Native` in `bin\lbxview.ini`, restart Total Commander, refresh thumbnails with Ctrl+R. If Native is also blank, the suspected problem is LBX object parsing or geometry, not just Brother COM.

**Diagnostic tool:** From the unzipped project root under Windows FPC 3.2.2:

```
diagnose-thumbnail.bat "C:\Path\to\problem-label.lbx"
```

It prints label width/length, parsed object count, object positions, Native thumbnail ink result, b-PAC ink result, and writes a `*.native-diagnostic.png` beside the input file (requires write access). No actual printing occurs.

**Additional tests:** Native thumbnail must contain visible dark pixels, blank b-PAC fixture must be detected as blank and nonblank b-PAC test image must be accepted. `tests/test_metadata_native.lpr` runs these during `build.bat` on Windows. The previous Python tests still run separately. This change has not been compiled with Windows FPC in this sandbox.

---

# LBXViewerWLX v3.2.1 – FPC 3.2.2 Buildfix

**Korrigiert:** Windows-Aufruf `SysUtils.GetEnvironmentVariable` und `Math.Max`/`Math.Min`-Overloads (siehe `BUILD_FIX_3_2_1.md`). Nativer Windows-Build muss noch vor Ort geprüft werden.

# LBXViewerWLX v3.2 – Etikettenmaße, Metadaten und label-only Thumbnails

**Status:** Vollständige FPC/Lazarus-Quellen ohne LCL; **21 von 21 Python-Referenz-/Vertrags-/Regressionsprüfungen bestanden**. Die Windows-DLL, der COM-Helper und die nativen FPC-Tests konnten **in dieser Linux-Umgebung nicht kompiliert oder ausgeführt werden**. Die unten genannten Windows-Tests sind vorhanden, aber **noch auszuführen**. Das ist kein Nachweis für Funktionsfähigkeit auf dem Zielsystem.

## Neu in Version 3.2 – feste Metadaten unter dem Etikett

Die **F3-Ansicht** ist in zwei Bereiche getrennt: oben das Etikett mit seiner
**tatsächlichen Dateilänge**, darunter ein **110 Bildschirm-Pixel hoher, nicht
zoombarer und nicht scrollbarer Metadatenbereich** mit fünf Zeilen:

- **Zuletzt geändert** aus `prop.xml` (`dcterms:modified`); wenn nicht vorhanden,
  letzte Änderung der LBX-Datei aus Windows. Beide Angaben werden gemäß der
  aktuellen **Windows-Zeitzone und lokalen Datums-/Zeitformatierung** angezeigt.
- **Zuletzt gedruckt** aus `prop.xml` (`meta:lastPrinted`) oder `-`, wenn nicht
  überliefert. Es wird kein Druckzeitpunkt erfunden.
- **Höhe des Labels** = physische Breite des Schriftbandes in mm (aus `style:paper/@width`)
  und **Länge** = Länge des Etiketts in mm (aus `style:paper/@height`, außer Autolänge).
- **Material** = lesbare Medienfamilie (z. B. P-touch-Schriftband) und
  in `style:paper` gespeicherte physische Bandbreite. Die numerischen Codes
  bleiben intern für die Diagnose verfügbar; der konkrete Kassettentyp ist
  ohne ausdrücklich gespeicherten Namen oder bestätigte Nutzerzuordnung unbekannt.
- **Drucker** aus `style:paper/@printerName` oder `nicht angegeben`.

Bei `autoLength="true"` ist `style:paper/@height` gewöhnlich der **1000-mm-Maximalwert**,
keine echte Etikettenlänge. Der Viewer errechnet die Länge stattdessen aus der
gekennzeichneten bedruckbaren Fläche `style:backGround`:
`x + width + 5.6pt` (rechter 2-mm-Vorlauf). Wenn die Fläche fehlt, wird eine
kurze **geschätzte Länge anhand der vorhandenen Objekte** verwendet, nie der
1000-mm-Platzhalter.

**Miniaturansicht:** `ListGetPreviewBitmapW`/`ListGetPreviewBitmap` zeichnen
**ausschließlich das Label**, ohne Metadaten, grauen Viewer-Hintergrund oder
Rahmen-Dekoration. Das Etikett wird **proportional auf die maximal mögliche
Vorschaubreite/-höhe skaliert und horizontal sowie vertikal zentriert**.
Bei einem typischen langen Beschriftungsband füllt es deshalb die volle Breite,
während oberhalb/unterhalb weiße Flächen bleiben.

**PNG-Export:** unverändert ausschließlich das eigentliche Etikett.
Brother b-PAC und der native FPC-Renderer benutzen dieselbe Größenbestimmung.
Zoom, Pan und Scrollleisten gelten nur für die Etikettenfläche, nicht den Footer.

**Beispiel (`Label TPZ Kabel LTE.lbx`, in Windows-Zeitzone Europe/Berlin):**

```
Zuletzt geändert: 17.03.2026 14:00:36
Zuletzt gedruckt: 17.03.2026 14:00:23
Höhe des Labels: 11,9 mm     Länge: 88,1 mm
Material: Brother P-touch-Schriftband, 12 mm (Material unbekannt)
Drucker: Brother PT-2430PC
```

Das tatsächliche Anzeigeformat kann je nach Windows-Ländereinstellung abweichen.

**Neue Tests:** `tests/test_metadata_thumbnail.py`, `tests/test_metadata_native.lpr`,
`examples/AutoLength_Background.lbx`. `build.bat` ruft den nativen Test nach
Kompilierung der WLX auf. Dieser native Test wurde hier mangels Windows-FPC
**noch nicht ausgeführt**. Die Bilder `preview-original-metadata.png` und
`thumbnail-original-label-only.png` sind Python-Referenzen, **keine Screenshots
von Total Commander**.

## Windows-Build-Fix in Version 3.1

Zwei vom Windows-FPC-Compiler 3.2.2 gemeldete Fehler in `src\lbxview.lpr` korrigiert: Klassenfeld-Anordnung (`TViewState`) und die Menü-ID von `TrackPopupMenu` (`LongBool`/`UINT`). Details in `BUILD_FIX_3_1.md`. **Der neue Build muss weiterhin auf Windows ausgeführt werden.**

## Neu in Version 3

**Renderer: Automatisch** ist der Standard. Die beiden Renderwege werden gleichermaßen für F3-Vorschau, Total-Commander-Miniaturansichten und PNG-Export eingesetzt:

1. Eingehende `.lbx` wird mit dem eigenen FPC-ZIP/XML-Parser eingelesen.
2. Ist der b-PAC-Host vorhanden, wird ein gültiger **zwischengespeicherter Brother-BMP-Export** gesucht. Cache-Schlüssel: vollständiger LBX-Pfad, Dateigröße, Änderungszeit, Auflösung (300 dpi) und Cache-Schema-Version.
3. Bei Fehlen des Cache startet die WLX einen **separaten Free-Pascal-Prozess** (`lbx-bpac-host.exe`), der per COM `bpac.Document` (alternativ `BrssCom.Document`) öffnet und als BMP exportiert (bei 300-dpi-Ablehnung erneuter Versuch mit 96 dpi). COM läuft **nie innerhalb des Total-Commander-Prozesses**.
4. Der WLX wartet maximal 3,5 Sekunden (konfigurierbar 300–15000 ms); hängende Hilfsprozesse werden beendet. Eine nicht verfügbare COM-Registrierung oder eine Zeitüberschreitung führt zu einer 60-Sekunden-Pause für weitere automatische COM-Versuche.
5. BMPs werden **vor der Verwendung** auf Signatur, Abmessungen, Pixelformat, Komprimierung, Farbpalette und ausreichende Dateigröße geprüft. Erfolgreiche BMPs werden atomar in den Cache übernommen und im F3-Fenster im Speicher gehalten.
6. Fehlt der Helper, b-PAC oder der Druckertreiber, oder schlagen Öffnen, Export, Timeout oder Dateiprüfung fehl, wird **ohne Fehlermeldung auf den Free-Pascal-Renderer zurückgegriffen**.

**Wichtig:** Für Etiketten mit externen CSV-Datensätzen verwendet der Lister weiterhin ausschließlich den FPC-Renderer, damit beim Seitenwechsel keine veralteten Brother-Daten angezeigt werden. Das Upgrade verändert die `.lbx`-Datei nicht und druckt nichts.

## Renderer-Einstellung

Per **Rechtsklick im Lister** auswählen:

| Einstellung | Verhalten |
|---|---|
| **Renderer: Automatisch** | Bevorzugt gültigen Brother-Cache und b-PAC; bei Fehler auf FPC zurück. Nach COM-Fehler/Timeout 60 s Schonfrist. **Voreinstellung.** |
| **Renderer: Nur FPC** | Keine Verwendung des Brother-Caches und kein Start des b-PAC-Hosts. |
| **Renderer: Brother bevorzugen** | Wie Auto, aber explizite erneute COM-Versuche auch während der 60-s-Schonfrist; der sichere FPC-Fallback bleibt bestehen. |

Persistenz: `bin\lbxview.ini`, Abschnitt `[Renderer]`, `Mode=Auto|Native|Brother`. Ändern über das Kontextmenü speichert die Einstellung, wenn der Plugin-Ordner beschreibbar ist; bei schreibgeschützten Verzeichnissen gilt sie nur bis Total Commander beendet wird. Alternative: Prozess-Umgebungsvariable `LBX_RENDER_MODE` (zum Beispiel `Native`) überschreibt die INI-Datei beim nächsten Start, sofern kein Modus im Kontextmenü gewählt wurde.

Ergänzende Umgebungsvariablen:

```bat
set "LBX_RENDER_MODE=Auto"
set "LBX_BPAC_TIMEOUT_MS=3500"
rem Optionalen 32-Bit-Host (oder Test-Host) mit ABSOLUTEM Pfad angeben:
set "LBX_BPAC_HOST=C:\Plugins\LBXViewerWLX\bin\lbx-bpac-host32.exe"
```

Ist `LBX_BPAC_HOST` nicht gesetzt, wird `lbx-bpac-host.exe` **neben der WLX-Datei** gesucht. Die EXE darf nicht aus einem untrusted Verzeichnis stammen. Es wird keine fremde DLL dynamisch in Total Commander geladen.

**Cache:** `%TEMP%\LBXViewerWLX-bpac-cache\*.bmp` (lokale, benutzerbezogene Windows-Temp-Dateien). Wird eine LBX geändert, erzeugen Größe/Änderungszeit einen neuen Schlüssel. Zum Löschen des Cache Total Commander beenden und diesen Ordner löschen. **Hinweis:** Gespeicherte BMPs enthalten den gerenderten Etiketteninhalt im Klartext; wenn solche Daten vertraulich sind, `Mode=Native` verwenden bzw. den Cache regelmäßig leeren. Cache-Einträge werden bislang nicht automatisch nach Alter/Größe gelöscht. Bei b-PAC-/Druckertreiber-Updates den Cache manuell löschen, damit die Darstellung neu berechnet wird.

## Installation / Windows-Build

Erforderlich: Windows, Free Pascal 3.2.2 oder neuer in der passenden Zielarchitektur und dessen RTL/FCL (unter anderem `Windows`, `ComObj`, `Variants`, `ActiveX`, `IniFiles`, `Zipper`, `XMLRead`, `DOM`, `FPQRCodeGen`, `FPImage`, `FPWritePNG`). **Keine Lazarus-LCL, kein Node.js und kein b-PAC für die FPC-Variante nötig.**

```bat
build.bat              rem 64 Bit: lbxview.wlx64 + 64-Bit-COM-Host + Tests
build.bat 32           rem 32 Bit: lbxview.wlx + 32-Bit-COM-Host + Tests
```

Dabei werden `bin\lbxview.wlx64` (bzw. `.wlx`), `bin\lbx-bpac-host.exe` und `bin\lbxview.ini` erstellt. Der Helper ist **kein Lister-Plugin**, sondern muss neben der WLX verbleiben. Anschließend in Total Commander: **Einstellungen → Plugins → Lister-Plugins (WLX)** und die `.wlx64`/`.wlx` hinzufügen. Für Thumbnails: Verwendung von Lister-Plugins für `*.lbx` aktivieren.

**32-Bit-b-PAC auf 64-Bit-Windows:** Die WLX muss zur Architektur von Total Commander passen (meist 64 Bit). Der separat gestartete COM-Host darf dagegen **32 Bit** sein, sofern die 32-Bit-b-PAC-Komponente registriert ist. Mit einer 32-Bit-FPC-Installation `build-helper32.bat` ausführen und `LBX_BPAC_HOST` auf die erzeugte `lbx-bpac-host32.exe` setzen. Unter Umständen ist die ältere Komponente nicht mit `.lbx` kompatibel; dann fällt die WLX zurück.

## Weitere bestehende Features

- F3-Vorschau, Zoom per **Strg + Mausrad**, `+`/`-`, `0`/`Home`, Scrollleisten, vertikales/horizontales Mausrad, Drag-Panning;
- WLX-Miniaturansicht über `ListGetPreviewBitmapW` und `ListGetPreviewBitmap`;
- **Strg + S** / Kontextmenü: PNG-Export mit 300-dpi-Bildabmessungen, wobei bei vorhandenem Brother-BMP die Brother-Grafik zugrunde liegt;
- gruppierte Objekte, Ebenen und XML-Z-Reihenfolge mit bekannten Einschränkungen für echte Brother-Gruppen;
- Schriftabschnitte, Rechtecke, Linien, BMP-Bilder mit Alpha, QR-Code, optionale `.bmp`-Rahmen über `LBX_FRAME_DIR`;
- CSV-Seriendruck in der FPC-Ansicht mit **Bild↑ / Bild↓**.

Die originale LBX liegt unter `examples\Label TPZ Kabel LTE.lbx`; zusätzliche synthetische Testdateien enthalten QR-Codes, Bilder, Rahmen und verschachtelte Gruppen.

## Tests und Diagnose

**Bereits ausgeführt (hier, Linux/Python):** `python -m pytest -q tests` → **21/21 bestanden**, darunter vorhandene Format-/Referenztests und weitere Tests für Aufbau und Verträge der COM-/Cache-/Fallback-Anbindung sowie 2 Build-Fix-Regressionsprüfungen. Die Referenz-PNGs entstehen mit Python und sind **kein ausgeführter Pascal- oder b-PAC-Export**.

**Unter Windows auszuführen (nach FPC-Build):** `build.bat` führt anschließend aus:

- `test_parser.exe` – Objektparser incl. Gruppen;
- `test_metadata_native.exe` – prop.xml, lokale Zeitstempel, echte/automatische Labelmaße, Metadaten-Footer, weiße zentrierte Miniatur;
- `wlx_smoke.exe` – echtes WLX-Thumbnail (64 Bit);
- `test_export.exe` – natives PNG-Format;
- `test_bpac_render.exe` – nativer GDI-Thumbnail- und PNG-Test mit simuliertem Brother-BMP;
- `test_bpac.exe` – **native** b-PAC-Transporttests mit `mock_bpac_host.exe`: Native-Modus, gültiger Brother-BMP, Cache-Hit, Dateisignaturänderung, fehlgeschlagener Export, ungültiges BMP, fehlendes COM, 60-s-Schonfrist, expliziter Retry, Timeout mit Prozessabbruch.

Die Mock-Tests benötigen **kein installiertes Brother b-PAC**, sie testen nur den Adapter. Für den echten Hersteller-Export das vorhandene Skript `tools\bpac-export-test.vbs` verwenden oder aus dem fertigen Projekt:

```bat
bin\lbx-bpac-host.exe "examples\Label TPZ Kabel LTE.lbx" "%TEMP%\lbx-bpac-live.bmp" 300
```

Exit-Code `0` = Export erfolgreich; `10` = COM nicht verfügbar; `11` = Vorlage kann nicht geöffnet werden; `12` = Export abgelehnt; `13` = COM-Exception. Die Ausgabedatei kann man mit einem Bildviewer kontrollieren. Ein tatsächlicher b-PAC-Livetransport konnte hier nicht getestet werden.

## Bekannte Grenzen

- b-PAC ist optional und **nicht zwangsläufig bei P-touch Editor 5/6 installiert**. Die passende COM-Laufzeit und für manche Vorlagen ein Druckertreiber können zusätzlich erforderlich sein.
- Die aktuelle Variante ruft COM in einem **synchron wartenden, aber zeitlich begrenzten** Hilfsprozess auf. Beim ersten nicht gecachten Etikett kann der Lister daher bis zum konfigurierten Timeout stocken. Später greifen Disk- und In-Memory-Cache. Für eine vollständig asynchrone Vorschaubearbeitung wäre eine weitere Ausbaustufe nötig.
- Ein sicherer FPC-Fallback bedeutet nicht pixelidentische Darstellung bei unbekannten dekorativen Brother-Rahmen. b-PAC zeigt das Etikett nur dann originalnah, wenn die lokale Brother-Installation das Dokument vollständig versteht.
- Cache-Signatur ist Pfad + Größe + Dateizeit (kein kryptographischer Hash des Dateiinhalts); sie kann bei künstlich gleichgehaltener Größe/Zeit veralten.
- PNG-Ausgabe verwendet 300-dpi-Pixelabmessungen, aber die PNG-Datei besitzt derzeit noch keine verlässliche eingebettete `pHYs`-DPI-Metadateninformation.
- Gruppentransformationen über Translation hinaus, proprietäre Brother-Rahmen, mehrere 1D-/2D-Barcodevarianten, mehrzeilige CSV-Quoted-Felder und Unicode-Sonderfälle müssen noch mit echten Brother-Dateien unter Windows getestet werden.

## Projektstruktur

```
src/lbxcore.pas           ZIP/XML-LBX-Parser, Gruppen, CSV und Bildressourcen
src/lbxrender.pas         Win32-GDI-Renderer, QR, Thumbnail, PNG, Brother-BMP
src/lbxview.lpr           WLX-Exports, Viewerfenster, Eingaben, Renderer-Wahl
src/lbxbpac.pas           b-PAC-Fallback, Timeout, Validierung, Disk-Cache
src/lbx-bpac-host.lpr     separater Free-Pascal-COM-Prozess
src/lbxview.lpi           Lazarus-Projekt ohne LCL
lbxview.ini               Default: [Renderer] Mode=Auto
build.bat                 native WLX + COM-Host + Tests unter Windows
build-helper32.bat        optionale 32-Bit-COM-Host-Variante
tests/mock_bpac_host.lpr  COM-Attrappe als Windows-Hilfsprozess
tests/test_bpac.lpr       Windows-Integrationsprüfungen für COM/Cache/Fallback
tests/test_bpac_render.lpr  nativer Test: Brother BMP -> Thumbnail / PNG
tests/test_bpac_contract.py   statische Linux-Vertragstests
tests/test_lbx.py          10 Python-Referenztests
tools/bpac-export-test.vbs    optionaler direkter Herstellervergleich
examples/                     reale und generierte LBX/BMP/CSV-Beispiele
```

## Vorbilder / Lizenz

Das LBX-Datenmodell orientiert sich an [bil-lbx](https://github.com/orochi235/bil-lbx) unter MIT-Lizenz, © 2026 Michael Baker (siehe `LICENSE-bil-lbx.txt`). COM-Methoden orientieren sich an der [Brother b-PAC-Dokumentation](https://support.brother.com/g/s/es/dev/en/bpac/index.html), Exporttyp `bexBmp = 4` an der b-PAC-3-Schnittstelle. Das WLX-ABI folgt dem [WLX-SDK von Christian Ghisler](https://github.com/ghisler/WLX-SDK). Es werden keine Brother-Binärdateien ausgeliefert.

## Fehlerbehebung v3.3.1 – Excel-Arbeitsblätter mit `$`

Ein P-touch-Seriendruck kann im LBX-Dateiformat auf `Tabelle1$` verweisen,
während die Arbeitsmappe das Blatt `Tabelle1` nennt. Der XLSX-Lader
berücksichtigt diese ODBC-Schreibweise jetzt automatisch. Exakte Blattnamen
haben Vorrang; fehlende Blätter werden weiterhin gemeldet.

Nach dem Einspielen: `build.bat` ausführen, die neue `bin\lbxview.wlx64`
in Total Commander verwenden, anschließend die Vorschau aktualisieren.
Die Regressionstests enthalten dafür Beispieldateien unter `examples`.

### Materialanzeige ab v3.4.8

Die Materialzeile zeigt statt der reinen Zahlen eine lesbare Medienfamilie und
Bandbreite an. Beispiele aus echten LBX-Dateien:

- `FK.lbx`, PT-2430PC, `media=0`, `format=259`, `width=33.6pt`:
  **Brother P-touch-Schriftband, 12 mm (Material unbekannt)**
- `TRUPPX.lbx`, PT-2430PC, `format=258`, `width=25.6pt`:
  **Brother P-touch-Schriftband, 9 mm (Material unbekannt)**

Das Format `258` wurde korrigiert: Für die untersuchten PT-Vorlagen steht es
für 9 mm. Media-IDs sind **geräteabhängig**: `259` hat bei einem Brother QL
nicht dieselbe Bedeutung wie bei einem PT. Die physische `paper.width` und die
Druckerfamilie werden deshalb vor einer Codezuordnung geprüft. Die Rohcodes
bleiben im Dokument erhalten, werden aber nicht mehr als Materialbeschreibung
im Metadatenbereich ausgegeben.

**Grenze:** Die LBX-Dateien speichern keine verlässliche TZe-Kassettennummer,
Farbe, Klebstoffart oder Laminierung. `paperColor`/`paperInk` sind Anzeige-
farben und kein Beweis für die tatsächlich eingesetzte Kassette. Für eine
verifizierte Materialbezeichnung können Sie weiterhin eine persönliche
`LBX_MATERIAL_MAP` angeben; druckerspezifische Abschnitte wie
`[Material:Brother PT-2430PC]` haben Vorrang vor `[Material]`.

**Nur optional und manuell:**
`powershell -NoProfile -ExecutionPolicy Bypass -File tools\\inspect-loaded-tape.ps1 -PrinterName "Brother PT-2430PC"`
fragt über b-PAC `GetMediaName` den **aktuell** eingelegten Bandtyp ab, sofern
b-PAC und der Drucker erreichbar sind. Dieser Wert ist keine historische
Eigenschaft der gespeicherten LBX-Datei und wird daher nicht stillschweigend
in deren Metadaten übernommen. Der Vorgang druckt kein Etikett.

Referenzen:
- https://docs.rs/crate/ptouch/latest/source/src/device.rs
- https://github.com/atans/bpac/blob/master/Printer.php
- https://www.brother.eu/-/media/pdf/buk/labelling/brother-tze-tape-information---english.pdf


## v3.4.10: P-touch-Textgenauigkeit (`W110`)

Die Version verwendet für `Label Kabel LTE.lbx` die tatsächlich gespeicherte Zentrierung (`CENTER`) und die vollständige Breite von 214 pt. Wichtig: Die zehn führenden und zehn abschließenden Leerzeichen bleiben erhalten; sie bestimmen die Position der zwei `W110`-Texte. Einzelne `text:stringItem`-Runs werden mit ihren originalen Schriftstärken gemessen, insbesondere ist das `I` normal (nicht fett). Eigenständige linke/rechte `Mobil-funk`-Textfelder verbleiben in ihren eigenen Boxen und Ebenen.

Für die native Win32/Win64-GDI-Prüfung mit Arial wird unter `build.bat` jetzt `tests/test_lte_native.lpr` ausgeführt. Ohne Windows-FPC können nur die quelltextbasierten und die Python-Referenztests durchgeführt werden. Siehe `CHANGELOG-v3.4.10.md`.

## v3.4.13: GS1-128-Klartextdarstellung

Neu: `humanReadable` steuert die Sichtbarkeit und `humanReadableAlignment`
steuert `LEFT`, `CENTER`, `RIGHT`. Die Klartextgröße wird über echte GDI-
Schriftmetriken in das Barcode-Rechteck eingepasst. Der untere Textbereich
reduziert bei aktiviertem Klartext die Balkenhöhe; ohne Klartext reichen die
Balken bis zum unteren Objektrand. Die Ruhezone für GS1-128 ist 10 Module je
Seite. Miniaturbilder und PNG verwenden denselben Renderer.

**Brother P-touch Editor 5.x:** Die eingebauten Barcode-Zeichen haben eine
feste Größe. Anpassbare Textgröße erfolgt über ein separates, mit dem Barcode
verknüpftes Textobjekt; dieses wird wie andere Textobjekte eigenständig
behandelt. Die optionalen Attribute `humanReadableFontSize` und
`humanReadableFontName` in den neuen FONT_*-Beispielen sind eine
Viewer-Erweiterung, **keine nachgewiesenen Brother-Standardattribute**.

Test mit dem fotografierten Inhalt `(01)04255596901149`:
`examples\GS1_HRI_CENTER.lbx` öffnen (nicht die Originaldatei des Fotos).
`build.bat` startet den zusätzlichen Windows-GDI-Pixeltest
`test_gs1_hri_native.exe`. Bei Fehlern bitte die genaue Compiler- oder
Testausgabe schicken. Für den nativen Renderer `Mode=Native` verwenden.

## v3.4.14: Drucken aus dem WLX

**Tastatur:** `Strg+P` im F3-Fenster. **Maus:** Rechtsklick → `Etikett drucken...` oder `Etikett ueber Windows-GDI drucken...`. Auch die TC-WLX-Funktionen `ListPrint` und `ListPrintW` werden exportiert.

Zuerst den **Windows-Drucker und das passende Bandformat** im Druckdialog wählen. Anschließend erscheint eine zweite Bestätigung mit Drucker, Etikettenlänge und Bandbreite, Stückzahl, Druckweg und – falls b-PAC den Drucker auslesen konnte – der **aktuell eingelegten Kassette**. Wenn das Medium nicht sicher bestimmt werden kann, erscheint stattdessen die Aufforderung, ein Schriftband der in der LBX angegebenen Breite einzulegen. Bei sicher erkannten Abweichungen wird nicht gedruckt.

**Druckwege:** Für Etiketten **ohne** Excel/CSV-Anbindung verwendet Auto bei vorhandenem b-PAC die Brother-Druckfunktion; für Seriendruck wird der aktuell ausgewählte Datensatz mittels Free-Pascal/GDI gerendert. Auch bei fehlendem b-PAC kann GDI genutzt werden, wenn der Treiber das korrekte Band-/Papierformat meldet. Der Viewer erzwingt keine proprietären Treibereinstellungen. Ein A4-Format wird als falsch zurückgewiesen.

Für den Brother-Druck ist zusätzlich zu `lbx-bpac-host.exe` die neue `lbx-bpac-print-host.exe` erforderlich. Die COM-Schnittstelle arbeitet an einer **temporären Kopie** der Originaldatei. Der Druck wird nach einer ausdrücklichen Bestätigung gestartet und nach Fehlern **niemals automatisch wiederholt**.

Automatische Tests drucken nicht. Für den sicheren Test mit deiner Kassette siehe [MANUAL_PRINT_TEST.md](MANUAL_PRINT_TEST.md) und [TESTREPORT-v3.4.14.md](TESTREPORT-v3.4.14.md).

## v3.4.47: BEC-Cliparts (P-touch 5.4)

`KFZ Smart.lbx` enthält `BEC,VEHICLE,10,Auto2`. Anders als `FONT`-Cliparts verweist
es auf den lokalen Katalog `Ptedit54\\Clipart\\Vehicle.xml`. v3.4.47 sucht diesen
Katalog gezielt und prüft sowohl vollständige Kennungen als auch den
Objektnamen `Auto2`. Die XML-Dekodierung bleibt vorerst auf erkannte sichere
lokale Rasterreferenzen beschränkt. Bei proprietären Inline-Vektordaten wird
ein Platzhalter angezeigt – die vorhandene XML-Datei allein garantiert noch
keine korrekte Clipart-Ausgabe.

**Diagnose:** `Diagnose-Clipart.cmd` ausführen und die erzeugte
`tools\\Clipart-Vehicle-Diagnose.txt` oder direkt `Vehicle.xml` für die
Format-Analyse bereitstellen. Das Werkzeug liest ausschließlich und
verändert keine Brother-Dateien.
